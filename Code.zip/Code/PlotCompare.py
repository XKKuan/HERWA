import re
import numpy as np
import matplotlib.pyplot as plt

def extract_data(file_path):
    """
    Extract checkpoint and incumbent_objs from .out file
    Format: "Batch XXXX: Incumbent objs YYY.YY < ZZZ, saving model..."
    or: "Incumbent objs and final step objs for validation are: XXX.XX YYY.YY validation takes:ZZ.ZZ"
    
    Args:
        file_path: Path to the .out file
    
    Returns:
        batches: List of checkpoint numbers (batch numbers)
        objs: List of incumbent_objs values
    """
    batches = []
    objs = []
    
    try:
        with open(file_path, 'r') as f:
            for line in f:
                # Pattern 1: "Batch 1730: Incumbent objs 840.05 < 842, saving model..."
                match1 = re.search(r'Batch\s+(\d+):\s*Incumbent\s+objs\s+([\d.]+)', line)
                
                # Pattern 2: "Incumbent objs and final step objs for validation are: 840.05 922.85"
                match2 = re.search(r'Incumbent\s+objs\s+and\s+final\s+step\s+objs\s+for\s+validation\s+are:\s+([\d.]+)', line)
                
                if match1:
                    batch_num = int(match1.group(1))
                    incumbent_obj = float(match1.group(2))
                    batches.append(batch_num)
                    objs.append(incumbent_obj)
                elif match2:
                    # 对于validation行，使用前一个batch number + 0.5 (或者不记录)
                    # 这里我们只记录第一个值（Incumbent objs）
                    incumbent_obj = float(match2.group(1))
                    if batches:  # 如果已经有batch记录
                        batches.append(batches[-1])  # 使用上一个batch号
                        objs.append(incumbent_obj)
        
        print(f"Extracted {len(batches)} data points from {file_path}")
        if len(batches) > 0:
            print(f"  First value: Batch {batches[0]}, Incumbent objs {objs[0]:.2f}")
            print(f"  Last value:  Batch {batches[-1]}, Incumbent objs {objs[-1]:.2f}")
        
        return batches, objs
    
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found!")
        return [], []
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        import traceback
        traceback.print_exc()
        return [], []

def moving_average(data, window_size):
    """Apply moving average smoothing"""
    if len(data) < window_size:
        return data
    return np.convolve(data, np.ones(window_size)/window_size, mode='valid')


class MultiSeedComparePlotter:
    """
    Multi-seed plotter for comparing multiple HERWA seeds against L2S
    """
    
    def __init__(self, herwa_files, l2s_file, seed_labels=None, window_size=10):
        """
        Initialize the plotter with multiple HERWA files and one L2S file
        
        Args:
            herwa_files: List of HERWA .out file paths
            l2s_file: Path to L2S .out file
            seed_labels: List of labels for HERWA seeds (optional)
            window_size: Window size for moving average smoothing
        """
        self.herwa_files = herwa_files
        self.l2s_file = l2s_file
        self.window_size = window_size
        
        # Generate default labels if not provided
        if seed_labels is None:
            self.seed_labels = [f'HERWA Seed {i+1}' for i in range(len(herwa_files))]
        else:
            self.seed_labels = seed_labels
        
        print("="*60)
        print("Initializing MultiSeedComparePlotter...")
        print("="*60)
        
        # Load all HERWA data
        self.herwa_data = []
        for i, file in enumerate(herwa_files):
            print(f"\nLoading {self.seed_labels[i]} from: {file}")
            batches, objs = extract_data(file)
            if len(objs) > 0:
                self.herwa_data.append({
                    'batches': batches,
                    'objs': objs,
                    'label': self.seed_labels[i],
                    'file': file
                })
                print(f"✓ Successfully loaded {len(objs)} points")
                print(f"  Range: {min(objs):.2f} to {max(objs):.2f}")
            else:
                print(f"✗ No data found in {file}")
        
        # Load L2S data
        print(f"\nLoading L2S from: {l2s_file}")
        self.l2s_batches, self.l2s_objs = extract_data(l2s_file)
        if len(self.l2s_objs) > 0:
            print(f"✓ Successfully loaded {len(self.l2s_objs)} points")
            print(f"  Range: {min(self.l2s_objs):.2f} to {max(self.l2s_objs):.2f}")
        else:
            print(f"✗ No data found in {l2s_file}")
        
        print("="*60)
    
    def plot_statistics_comparison(self, output_path='multi_seed_statistics.png'):
        """
        Create statistical comparison plot with multiple HERWA seeds vs L2S
        """
        print("\n📊 Creating multi-seed statistics comparison plot...")
        
        if len(self.herwa_data) == 0 or len(self.l2s_objs) == 0:
            print("Error: No data available for plotting!")
            return
        
        # Calculate statistics for L2S
        l2s_mean = np.mean(self.l2s_objs)
        l2s_var = np.var(self.l2s_objs)
        l2s_std = np.std(self.l2s_objs)
        l2s_min = np.min(self.l2s_objs)
        l2s_max = np.max(self.l2s_objs)
        
        # Calculate statistics for all HERWA seeds
        herwa_stats = []
        for data in self.herwa_data:
            herwa_stats.append({
                'label': data['label'],
                'mean': np.mean(data['objs']),
                'var': np.var(data['objs']),
                'std': np.std(data['objs']),
                'min': np.min(data['objs']),
                'max': np.max(data['objs'])
            })
        
        # Create figure
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6), facecolor='white')
        
        # Define colors - different colors for HERWA seeds, red for L2S
        herwa_colors = ['#5470C6', '#91CC75', '#FAC858']  # Blue, Green, Yellow
        l2s_color = '#EE6666'  # Red
        
        # Prepare data
        n_seeds = len(self.herwa_data)
        x_positions = np.arange(n_seeds + 1)  # positions for bars
        width = 0.6
        
        # ============ Left: Mean Comparison ============
        means = [stats['mean'] for stats in herwa_stats] + [l2s_mean]
        colors = herwa_colors[:n_seeds] + [l2s_color]
        labels = [data['label'] for data in self.herwa_data] + ['L2S']
        
        bars1 = ax1.bar(x_positions, means, width, color=colors, alpha=0.85,
                       edgecolor='black', linewidth=1.2)
        
        # Add value labels on top
        for i, (bar, mean_val) in enumerate(zip(bars1, means)):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height,
                    f'{mean_val:.2f}',
                    ha='center', va='bottom', fontsize=11, fontweight='bold')
        
        ax1.set_ylabel('Mean Incumbent Objs', fontsize=13, fontweight='bold')
        ax1.set_title('Mean Incumbent Objs Comparison', fontsize=14, fontweight='bold', pad=15)
        ax1.set_xticks(x_positions)
        ax1.set_xticklabels(labels, fontsize=11)
        ax1.grid(True, alpha=0.3, axis='y', linestyle='--')
        ax1.set_ylim(0, max(means) * 1.15)
        ax1.set_axisbelow(True)
        
        # ============ Right: Variance Comparison ============
        variances = [stats['var'] for stats in herwa_stats] + [l2s_var]
        stds = [stats['std'] for stats in herwa_stats] + [l2s_std]
        
        bars2 = ax2.bar(x_positions, variances, width, color=colors, alpha=0.85,
                       edgecolor='black', linewidth=1.2)
        
        # Add value labels with variance and std
        for i, (bar, var_val, std_val) in enumerate(zip(bars2, variances, stds)):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                    f'Var: {var_val:.2f}\nStd: {std_val:.2f}',
                    ha='center', va='bottom', fontsize=9, fontweight='bold')
        
        ax2.set_ylabel('Variance of Incumbent Objs', fontsize=13, fontweight='bold')
        ax2.set_title('Variance Comparison', fontsize=14, fontweight='bold', pad=15)
        ax2.set_xticks(x_positions)
        ax2.set_xticklabels(labels, fontsize=11)
        ax2.grid(True, alpha=0.3, axis='y', linestyle='--')
        ax2.set_ylim(0, max(variances) * 1.25)
        ax2.set_axisbelow(True)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f'✓ Multi-seed statistics plot saved as {output_path}')
        plt.close()
        
        # Print statistics summary
        print(f"\n{'='*70}")
        print(f"📈 Statistical Summary:")
        print(f"{'='*70}")
        for stats in herwa_stats:
            print(f"\n{stats['label']}:")
            print(f"  Mean:     {stats['mean']:8.2f}")
            print(f"  Variance: {stats['var']:8.2f}")
            print(f"  Std Dev:  {stats['std']:8.2f}")
            print(f"  Min:      {stats['min']:8.2f}")
            print(f"  Max:      {stats['max']:8.2f}")
        print(f"\nL2S:")
        print(f"  Mean:     {l2s_mean:8.2f}")
        print(f"  Variance: {l2s_var:8.2f}")
        print(f"  Std Dev:  {l2s_std:8.2f}")
        print(f"  Min:      {l2s_min:8.2f}")
        print(f"  Max:      {l2s_max:8.2f}")
        print(f"{'='*70}\n")
    
    def plot_convergence_curves(self, output_path='multi_seed_convergence.png'):
        """
        Plot convergence curves for all HERWA seeds and L2S
        """
        print("📈 Creating multi-seed convergence curves...")
        
        if len(self.herwa_data) == 0 or len(self.l2s_objs) == 0:
            print("Error: No data available for plotting!")
            return
        
        fig, ax = plt.subplots(figsize=(14, 7), facecolor='white')
        
        # Colors
        herwa_colors = ['#5470C6', '#91CC75', '#FAC858']
        l2s_color = '#EE6666'
        
        # Plot each HERWA seed
        for i, data in enumerate(self.herwa_data):
            # Original data (light)
            ax.plot(data['batches'], data['objs'],
                   color=herwa_colors[i], linewidth=0.8,
                   alpha=0.3, linestyle='-')
            
            # Smoothed data (bold)
            if len(data['objs']) >= self.window_size:
                smoothed = moving_average(data['objs'], self.window_size)
                # Adjust batch numbers for smoothed data
                smoothed_batches = data['batches'][self.window_size-1:]
                
                ax.plot(smoothed_batches, smoothed,
                       color=herwa_colors[i], linewidth=2.5,
                       label=f"{data['label']} (smoothed)",
                       alpha=0.9)
            else:
                ax.plot(data['batches'], data['objs'],
                       color=herwa_colors[i], linewidth=2.5,
                       label=data['label'],
                       alpha=0.9)
        
        # Plot L2S - original (light)
        ax.plot(self.l2s_batches, self.l2s_objs,
               color=l2s_color, linewidth=0.8,
               alpha=0.3, linestyle='-')
        
        # Plot L2S - smoothed (bold)
        if len(self.l2s_objs) >= self.window_size:
            l2s_smoothed = moving_average(self.l2s_objs, self.window_size)
            l2s_smoothed_batches = self.l2s_batches[self.window_size-1:]
            
            ax.plot(l2s_smoothed_batches, l2s_smoothed,
                   color=l2s_color, linewidth=2.5,
                   label=f"L2S (smoothed)",
                   alpha=0.9)
        else:
            ax.plot(self.l2s_batches, self.l2s_objs,
                   color=l2s_color, linewidth=2.5,
                   label="L2S",
                   alpha=0.9)
        
        ax.set_xlabel('Batch Number', fontsize=13, fontweight='bold')
        ax.set_ylabel('Incumbent Objs Value', fontsize=13, fontweight='bold')
        ax.set_title(f'Multi-Seed Convergence Comparison (Window Size={self.window_size})', 
                    fontsize=15, fontweight='bold')
        ax.legend(fontsize=11, loc='best', framealpha=0.95, edgecolor='black')
        ax.grid(True, alpha=0.3, linestyle='--')
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f'✓ Multi-seed convergence plot saved as {output_path}')
        plt.close()
    
    def plot_all(self):
        """Generate all plots"""
        self.plot_statistics_comparison()
        self.plot_convergence_curves()


def main():
    """
    Main function for multi-seed comparison
    """
    print("\n" + "="*60)
    print("🚀 Multi-Seed HERWA vs L2S Comparison Tool")
    print("="*60 + "\n")
    
    # ============ 配置区 - 修改为你的实际文件路径 ============
    
    # HERWA的三个seed结果文件
    herwa_files = [
        'TrainEntropy.out',    # Seed 1的结果文件
        'Train_seed_10.out',    # Seed 2的结果文件
        'Train_seed100.out'     # Seed 3的结果文件
    ]
    
    # L2S的结果文件
    l2s_file = 'TrainResult.out'
    
    # 可选：自定义每个seed的标签
    seed_labels = [
        'HERWA Seed 1',
        'HERWA Seed 10', 
        'HERWA Seed 100'
    ]
    
    # 平滑窗口大小
    window_size = 10
    
    # ============ 开始分析 ============
    
    try:
        # Create plotter
        plotter = MultiSeedComparePlotter(
            herwa_files=herwa_files,
            l2s_file=l2s_file,
            seed_labels=seed_labels,
            window_size=window_size
        )
        
        # Generate all plots
        print("\n" + "="*60)
        print("📊 Generating Plots...")
        print("="*60 + "\n")
        
        plotter.plot_all()
        
        print("\n" + "="*60)
        print("✅ Multi-seed analysis completed successfully!")
        print("="*60)
        print("\nGenerated files:")
        print("  📄 multi_seed_statistics.png - Statistical comparison")
        print("  📄 multi_seed_convergence.png - Convergence curves")
        print("="*60 + "\n")
        
    except Exception as e:
        print(f"\n❌ Error during analysis: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()