import os
from typing import Dict, Iterable, List, Optional, Tuple

import torch


class SWAG:
    """
    SWA-Gaussian (diagonal) aggregator for PyTorch state_dict parameters.

    This class accumulates per-parameter means and variances across multiple
    checkpoints and can sample weights from the resulting Gaussian posterior
    approximation.
    """

    def __init__(self, device: Optional[torch.device] = None) -> None:
        self.device = device if device is not None else torch.device("cpu")
        self.parameter_mean_by_name: Dict[str, torch.Tensor] = {}
        self.parameter_sq_mean_by_name: Dict[str, torch.Tensor] = {}
        self.num_models_accumulated: int = 0

    @torch.no_grad()
    def add_model_from_state_dict(self, state_dict: Dict[str, torch.Tensor]) -> None:
        """
        Accumulate statistics from a model state_dict.
        """
        if not state_dict:
            return

        if self.num_models_accumulated == 0:
            # Initialize running stats with zeros matching parameter shapes
            for name, tensor in state_dict.items():
                if not torch.is_tensor(tensor):
                    continue
                self.parameter_mean_by_name[name] = tensor.detach().to(self.device).clone()
                self.parameter_sq_mean_by_name[name] = (tensor.detach().to(self.device) ** 2).clone()
            self.num_models_accumulated = 1
            return

        # Online update of mean and squared-mean for each parameter (per-parameter diagonal approx)
        new_count = self.num_models_accumulated + 1
        for name, tensor in state_dict.items():
            if not torch.is_tensor(tensor):
                continue
            param = tensor.detach().to(self.device)

            if name not in self.parameter_mean_by_name:
                # New parameter appeared; initialize properly
                self.parameter_mean_by_name[name] = param.clone()
                self.parameter_sq_mean_by_name[name] = (param ** 2).clone()
                continue

            # Incremental mean: m_new = m + (x - m) / n
            old_mean = self.parameter_mean_by_name[name]
            delta = param - old_mean
            self.parameter_mean_by_name[name] = old_mean + delta / new_count

            # Incremental squared mean: E[x^2]
            old_sq_mean = self.parameter_sq_mean_by_name[name]
            delta_sq = (param ** 2) - old_sq_mean
            self.parameter_sq_mean_by_name[name] = old_sq_mean + delta_sq / new_count

        self.num_models_accumulated = new_count

    @torch.no_grad()
    def add_model(self, model: torch.nn.Module) -> None:
        self.add_model_from_state_dict(model.state_dict())

    def _variance_from_stats(self, name: str) -> torch.Tensor:
        mean = self.parameter_mean_by_name[name]
        sq_mean = self.parameter_sq_mean_by_name[name]
        var = sq_mean - mean.pow(2)
        # Numerical safety: clamp to non-negative
        return torch.clamp(var, min=0.0)

    @torch.no_grad()
    def finalize(self) -> Dict[str, Tuple[torch.Tensor, torch.Tensor]]:
        """
        Returns a dictionary mapping parameter name -> (mean, variance).
        """
        stats: Dict[str, Tuple[torch.Tensor, torch.Tensor]] = {}
        if self.num_models_accumulated == 0:
            return stats
        for name in self.parameter_mean_by_name.keys():
            stats[name] = (
                self.parameter_mean_by_name[name].clone(),
                self._variance_from_stats(name).clone(),
            )
        return stats

    @torch.no_grad()
    def sample_into_model(self, model: torch.nn.Module, scale: float = 1.0, seed: Optional[int] = None) -> None:
        """
        Sample weights from the SWAG Gaussian (diagonal) and load into `model`.
        """
        if seed is not None:
            generator = torch.Generator(device=self.device)
            generator.manual_seed(seed)
        else:
            generator = None

        if self.num_models_accumulated == 0:
            return

        with torch.no_grad():
            state_dict = model.state_dict()
            for name, param_tensor in state_dict.items():
                if name not in self.parameter_mean_by_name:
                    # Skip parameters not observed in aggregation
                    continue
                mean = self.parameter_mean_by_name[name]
                var = self._variance_from_stats(name)
                std = torch.sqrt(torch.clamp(var, min=0.0))
                if generator is not None:
                    noise = torch.randn_like(mean, device=self.device)
                    # 手动设置随机种子
                    torch.manual_seed(seed if seed is not None else 0)
                else:
                    noise = torch.randn_like(mean, device=self.device)
                sampled = mean + scale * std * noise

                # Ensure device and dtype match target parameter
                state_dict[name] = sampled.to(device=param_tensor.device, dtype=param_tensor.dtype)

            model.load_state_dict(state_dict)

    @torch.no_grad()
    def save(self, filepath: str) -> None:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        torch.save(
            {
                "mean": self.parameter_mean_by_name,
                "sq_mean": self.parameter_sq_mean_by_name,
                "num_models": self.num_models_accumulated,
                "device": str(self.device),
            },
            filepath,
        )

    @torch.no_grad()
    def load(self, filepath: str, map_location: Optional[str] = None) -> None:
        payload = torch.load(filepath, map_location=map_location or str(self.device))
        self.parameter_mean_by_name = {k: v.to(self.device) for k, v in payload.get("mean", {}).items()}
        self.parameter_sq_mean_by_name = {k: v.to(self.device) for k, v in payload.get("sq_mean", {}).items()}
        self.num_models_accumulated = int(payload.get("num_models", 0))

    @torch.no_grad()
    def load_checkpoints(self, checkpoint_paths: Iterable[str], map_location: Optional[str] = None) -> int:
        """
        Load multiple checkpoints (PyTorch .pth files) and accumulate their statistics.
        Returns number of successfully loaded checkpoints.
        """
        count_loaded = 0
        for path in checkpoint_paths:
            try:
                state = torch.load(path, map_location=map_location or str(self.device))
                # Accept both state_dict or plain dict from torch.save(model.state_dict(), ...)
                if isinstance(state, dict):
                    self.add_model_from_state_dict(state)
                    count_loaded += 1
            except Exception:
                # Skip files that cannot be read as PyTorch checkpoints
                continue
        return count_loaded

    @torch.no_grad()
    def scan_and_load_from_directory(self, directory: str, suffix: str = ".pth", map_location: Optional[str] = None) -> int:
        """
        Convenience: scan a directory for checkpoint files ending with suffix and aggregate them.
        """
        if not os.path.isdir(directory):
            return 0
        candidates: List[str] = [
            os.path.join(directory, filename)
            for filename in os.listdir(directory)
            if filename.endswith(suffix)
        ]
        return self.load_checkpoints(candidates, map_location=map_location)


