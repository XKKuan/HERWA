#!/usr/bin/env python3
"""
从savemodel目录加载模型检查点，使用SWAG计算均值和方差，构建高斯分布
"""

import os
import sys
import torch
import glob
from pathlib import Path

# 添加路径
sys.path.append('/root/data1/HERWA/L2S-main')
from model.swag import SWAG

def load_models_from_savemodel(savemodel_dir: str, device: str = "cpu"):
    """
    从savemodel目录加载所有.pth文件并计算SWAG统计信息
    
    Args:
        savemodel_dir: savemodel目录路径
        device: 计算设备 ('cpu' 或 'cuda')
    
    Returns:
        SWAG对象，包含计算好的均值和方差
    """
    # 创建SWAG实例
    swag = SWAG(device=torch.device(device))
    
    # 查找所有.pth文件
    pattern = os.path.join(savemodel_dir, "*.pth")
    model_files = glob.glob(pattern)
    
    if not model_files:
        print(f"在 {savemodel_dir} 中没有找到.pth文件")
        return None
    
    print(f"找到 {len(model_files)} 个模型文件")
    
    # 加载所有模型检查点
    loaded_count = swag.load_checkpoints(model_files, map_location=device)
    print(f"成功加载了 {loaded_count} 个模型检查点")
    
    return swag

def analyze_swag_distribution(swag: SWAG):
    """
    分析SWAG计算的高斯分布统计信息
    
    Args:
        swag: 已计算统计信息的SWAG对象
    """
    if swag.num_models_accumulated == 0:
        print("没有加载任何模型，无法分析分布")
        return
    
    print(f"\n=== SWAG 分布分析 ===")
    print(f"累积模型数量: {swag.num_models_accumulated}")
    
    # 获取所有参数的统计信息
    stats = swag.finalize()
    
    print(f"参数总数: {len(stats)}")
    
    # 分析每个参数的统计信息
    total_params = 0
    for name, (mean, var) in stats.items():
        param_count = mean.numel()
        total_params += param_count
        
        mean_val = mean.mean().item()
        var_val = var.mean().item()
        std_val = torch.sqrt(var).mean().item()
        
        print(f"参数 {name}:")
        print(f"  - 参数数量: {param_count}")
        print(f"  - 均值: {mean_val:.6f}")
        print(f"  - 方差: {var_val:.6f}")
        print(f"  - 标准差: {std_val:.6f}")
        print()
    
    print(f"总参数数量: {total_params}")

def sample_and_save_models(swag: SWAG, base_model, num_samples: int = 5, 
                          save_dir: str = "sampled_models", scale: float = 1.0):
    """
    从SWAG分布中采样多个模型并保存
    
    Args:
        swag: SWAG对象
        base_model: 基础模型实例
        num_samples: 采样数量
        save_dir: 保存目录
        scale: 采样缩放因子
    """
    if swag.num_models_accumulated == 0:
        print("没有加载任何模型，无法采样")
        return
    
    os.makedirs(save_dir, exist_ok=True)
    
    print(f"\n=== 从SWAG分布采样 {num_samples} 个模型 ===")
    
    for i in range(num_samples):
        # 创建模型副本 - 需要传入正确的参数
        device = next(base_model.parameters()).device
        sampled_model = create_actor_model(device)
        
        # 从SWAG分布采样
        swag.sample_into_model(sampled_model, scale=scale, seed=i)
        
        # 保存采样模型
        save_path = os.path.join(save_dir, f"sampled_model_{i:03d}.pth")
        torch.save(sampled_model.state_dict(), save_path)
        print(f"采样模型 {i+1}/{num_samples} 已保存到: {save_path}")

def create_actor_model(device="cpu"):
    """
    创建Actor模型实例
    """
    # 导入Actor类
    import sys
    sys.path.append('/root/data1/HERWA/L2S-main')
    from model.actor import Actor
    
    # 根据文件名推断参数（从文件名中提取）
    # 例如: last-step_10x10[1,99]_fdd-divide-mwkr_yaoxin_1_128_4_4_gin+dghan_1_0.0_5e-05_10_500_64_128000_10_batch2000.pth
    # 参数: in_dim=3, hidden_dim=128, embedding_l=4, policy_l=4, embedding_type='gin+dghan', heads=1, dropout=0.0
    
    actor = Actor(
        in_dim=3,
        hidden_dim=128,
        embedding_l=4,
        policy_l=4,
        embedding_type='gin+dghan',
        heads=1,
        dropout=0.0
    ).to(device)
    
    return actor

def main():
    """主函数"""
    # 设置路径
    savemodel_dir = "/root/data1/HERWA/L2S-main/savemodel"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    print(f"使用设备: {device}")
    print(f"从目录加载模型: {savemodel_dir}")
    
    # 加载模型并计算SWAG统计信息
    swag = load_models_from_savemodel(savemodel_dir, device)
    
    if swag is None:
        return
    
    # 分析分布
    analyze_swag_distribution(swag)
    
    # 保存SWAG统计信息
    swag_stats_path = "/root/data1/HERWA/L2S-main/swag_statistics.pth"
    swag.save(swag_stats_path)
    print(f"\nSWAG统计信息已保存到: {swag_stats_path}")
    
    # 创建Actor模型并采样
    print("\n=== 创建Actor模型并采样 ===")
    try:
        base_model = create_actor_model(device)
        print("Actor模型创建成功")
        
        # 采样并保存模型
        sample_and_save_models(swag, base_model, num_samples=5, save_dir="/root/data1/HERWA/L2S-main/sampled_models")
        
    except Exception as e:
        print(f"创建或采样模型时出错: {e}")
        print("请检查模型参数是否正确")

if __name__ == "__main__":
    main()
