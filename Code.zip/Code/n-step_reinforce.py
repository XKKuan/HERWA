import time
import random
import numpy as np
import numpy.random
from parameters import args
import torch
import torch.optim as optim
from env.environment import JsspN5, BatchGraph
from model.actor import Actor
from env.generateJSP import uni_instance_gen
from pathlib import Path


class RL2S4JSSP:
    def __init__(self):
        self.env_training = JsspN5(n_job=args.j, n_mch=args.m, low=args.l, high=args.h, reward_type=args.reward_type)
        self.env_validation = JsspN5(n_job=args.j, n_mch=args.m, low=args.l, high=args.h, reward_type=args.reward_type)
        self.eps = np.finfo(np.float32).eps.item()
        
        # ========== 熵正则化参数 ==========
        # Alpha参数设置
        self.alpha_init = getattr(args, 'alpha_init', 0.1)  # alpha初始值
        self.alpha = self.alpha_init
        self.alpha_min = getattr(args, 'alpha_min', 0.01)  # alpha最小值
        self.alpha_max = getattr(args, 'alpha_max', 0.08)    # alpha最大值
        
        # Alpha更新方式选择
        self.alpha_update_method = getattr(args, 'alpha_update_method', 'adaptive')  # 'fixed', 'adaptive', 'exponential', 'lagrangian'
        self.alpha_lr = getattr(args, 'alpha_lr', 1e-4)  # alpha学习率 (按照论文设置)
        self.alpha_decay = getattr(args, 'alpha_decay', 0.99)  # 指数衰减率
        self.alpha_decay_steps = getattr(args, 'alpha_decay_steps', 1000)  # 衰减步数
        
        # 目标熵设置
        self.target_entropy_method = getattr(args, 'target_entropy_method', 'cosine_annealing')
        
        # ========== Cosine Annealing 专用参数 ==========
        self.n_restart = getattr(args, 'n_restart', 4)  # 重启次数
        self.k_min = getattr(args, 'k_min', 3)  # 收敛强度参数
        self.avg_action_space_size = getattr(args, 'avg_action_space_size', 15)  # 平均动作空间大小
        
        # 计算总训练步数和周期长度
        self.total_episodes = args.episodes
        self.total_training_steps = (args.episodes // args.batch_size) * (args.transit // args.steps_learn)
        self.cycle_length = self.total_training_steps // (self.n_restart + 1)
        
        # 计算 H_max 和 H_min
        import math
        self.H_max = math.log(self.avg_action_space_size / math.e)  # log(|A|/e)
        self.H_min = math.log(self.avg_action_space_size / (math.e ** self.k_min))  # log(|A|/e^k)
        
        print(f"\n{'='*60}")
        print(f"Cosine Annealing Target Entropy Configuration:")
        print(f"{'='*60}")
        print(f"Total Episodes:        {self.total_episodes}")
        print(f"Total Training Steps:  {self.total_training_steps}")
        print(f"Number of Restarts:    {self.n_restart}")
        print(f"Cycle Length:          {self.cycle_length} steps")
        print(f"Avg Action Space Size: {self.avg_action_space_size}")
        print(f"Convergence Strength:  k = {self.k_min}")
        print(f"H_max (Initial):       {self.H_max:.4f}")
        print(f"H_min (Converged):     {self.H_min:.4f}")
        print(f"{'='*60}\n")
        
        # 动态调整参数
        self.entropy_history = []  # 熵历史记录
        self.entropy_history_size = getattr(args, 'entropy_history_size', 100)  # 历史记录大小
        self.entropy_smoothing = getattr(args, 'entropy_smoothing', 0.9)  # 熵平滑系数
        
        # 自适应学习率参数
        self.alpha_lr_multipliers = getattr(args, 'alpha_lr_multipliers', [1.0, 0.5, 0.1])  # 学习率倍数
        self.entropy_error_thresholds = getattr(args, 'entropy_error_thresholds', [0.1, 0.3, 0.5])  # 误差阈值
        
        # 训练进度相关
        self.total_episodes = args.episodes
        self.current_episode = 0
        self.training_step = 0
        
        validation_data_path = Path(
            './validation_data/validation_instance_{}x{}[{},{}].npy'.format(args.j, args.m, args.l, args.h))
        if validation_data_path.is_file():
            self.validation_data = np.load(
                './validation_data/validation_instance_{}x{}[{},{}].npy'.format(args.j, args.m, args.l, args.h))
        else:
            print('No validation data for {}x{}[{},{}], generating new one.'.format(args.j, args.m, args.l, args.h))
            self.validation_data = np.array(
                [uni_instance_gen(n_j=args.j, n_m=args.m, low=args.l, high=args.h) for _ in range(100)])
            np.save('./validation_data/validation_instance_{}x{}[{},{}].npy'.format(args.j, args.m, args.l, args.h),
                    self.validation_data)
        self.incumbent_validation_result = np.inf
        self.current_validation_result = np.inf

        if args.embedding_type == 'gin':
            self.dghan_param_for_saved_model = 'NAN'
        elif args.embedding_type == 'dghan' or args.embedding_type == 'gin+dghan':
            self.dghan_param_for_saved_model = '{}_{}'.format(args.heads, args.drop_out)
        else:
            raise Exception('embedding_type should be one of "gin", "dghan", or "gin+dghan".')

    def update_alpha(self, current_entropy, target_entropy, step):
        """
        根据拉格朗日对偶的自适应温度控制更新alpha参数
        基于公式: α_{t+1} = α_t + η_α (H_target - H(π(·|s_t)))
        """
        if self.alpha_update_method == 'fixed':
            # 固定alpha，不更新
            pass
            
        elif self.alpha_update_method == 'adaptive':
            # 标准自适应更新：基于拉格朗日对偶公式
            # α_{t+1} = α_t + η_α (H_target - H(π(·|s_t)))
            entropy_error = target_entropy - current_entropy
            
            # 使用固定学习率进行更新
            alpha_update = self.alpha_lr * entropy_error
            self.alpha += alpha_update
            
            # 限制alpha范围
            self.alpha = max(self.alpha_min, min(self.alpha_max, self.alpha))
            
        elif self.alpha_update_method == 'adaptive_lr':
            # 带学习率调整的自适应更新
            entropy_error = target_entropy - current_entropy
            
            # 根据误差大小选择学习率倍数
            effective_lr = self.alpha_lr
            for i, threshold in enumerate(self.entropy_error_thresholds):
                if abs(entropy_error) > threshold:
                    effective_lr = self.alpha_lr * self.alpha_lr_multipliers[i]
                    break
            
            # 更新alpha: α_{t+1} = α_t + η_α (H_target - H(π(·|s_t)))
            alpha_update = effective_lr * entropy_error
            self.alpha += alpha_update
            self.alpha = max(self.alpha_min, min(self.alpha_max, self.alpha))
            
        elif self.alpha_update_method == 'exponential':
            # 指数衰减更新
            if step % self.alpha_decay_steps == 0:
                self.alpha *= self.alpha_decay
                self.alpha = max(self.alpha_min, self.alpha)
                
        elif self.alpha_update_method == 'lagrangian':
            # 完整的拉格朗日对偶更新
            # 计算拉格朗日对偶目标: J(α) = E[α (H(π) - H_target)]
            entropy_error = current_entropy - target_entropy  # H(π) - H_target
            
            # 梯度更新: α_{t+1} = α_t + η_α (H_target - H(π))
            # 注意：这里使用负梯度，因为我们要最大化J(α)
            alpha_gradient = target_entropy - current_entropy  # H_target - H(π)
            alpha_update = self.alpha_lr * alpha_gradient
            self.alpha += alpha_update
            self.alpha = max(self.alpha_min, min(self.alpha_max, self.alpha))

    def get_target_entropy(self, current_entropy, step):
        """
        根据选择的方法计算目标熵
        支持 Cosine Annealing with Warm Restart
        """
        if self.target_entropy_method == 'cosine_annealing':
            # ========== Cosine Annealing with Warm Restart ==========
            import math
            
            # 计算当前在周期内的位置
            t_cycle = step % self.cycle_length
            
            # 计算余弦退火目标熵
            # H_target(t) = H_min + 0.5*(H_max - H_min)*[1 + cos(π*t_cycle/T_cycle)]
            cosine_term = math.cos(math.pi * t_cycle / self.cycle_length)
            target_entropy = self.H_min + 0.5 * (self.H_max - self.H_min) * (1 + cosine_term)
            
            # 记录当前周期信息（用于调试）
            current_cycle = step // self.cycle_length
            progress_in_cycle = t_cycle / self.cycle_length
            
            # 每个周期开始时打印信息
            if t_cycle == 0 and step > 0:
                print(f"\n{'='*60}")
                print(f"🔄 WARM RESTART - Cycle {current_cycle + 1}/{self.n_restart + 1}")
                print(f"{'='*60}")
                print(f"Step: {step}, H_target reset to {target_entropy:.4f}")
                print(f"{'='*60}\n")
            
            # 保存调试信息
            if not hasattr(self, 'cosine_annealing_log'):
                self.cosine_annealing_log = []
            
            self.cosine_annealing_log.append({
                'step': step,
                'cycle': current_cycle,
                'progress_in_cycle': progress_in_cycle,
                'target_entropy': target_entropy,
                'current_entropy': current_entropy
            })
            
            return target_entropy
        
        elif self.target_entropy_method == 'fixed':
            # 固定目标熵：基于初始熵的比例
            if not hasattr(self, 'initial_entropy'):
                self.initial_entropy = current_entropy
            return self.initial_entropy * self.target_entropy_ratio
        
        elif self.target_entropy_method == 'adaptive':
            # 自适应目标熵：基于当前熵动态调整
            return current_entropy * self.target_entropy_ratio
        
        elif self.target_entropy_method == 'moving_avg':
            # 移动平均目标熵：基于历史熵的平均值
            self.entropy_history.append(current_entropy)
            if len(self.entropy_history) > self.entropy_history_size:
                self.entropy_history.pop(0)
            
            if len(self.entropy_history) > 0:
                avg_entropy = sum(self.entropy_history) / len(self.entropy_history)
                return avg_entropy * self.target_entropy_ratio
            else:
                return current_entropy * self.target_entropy_ratio
        
        elif self.target_entropy_method == 'progressive':
            # 渐进式目标熵：随训练进度逐渐降低
            progress = self.current_episode / self.total_episodes
            if not hasattr(self, 'initial_entropy'):
                self.initial_entropy = current_entropy
            
            target_ratio = self.target_entropy_ratio * (1 - progress * 0.5)
            target_ratio = max(0.1, target_ratio)
            
            return self.initial_entropy * target_ratio
        
        elif self.target_entropy_method == 'formula':
            # 使用论文公式: H_target = log(|A|/e)
            import math
            avg_action_space_size = getattr(self, 'avg_action_space_size', 10)
            target_entropy = math.log(avg_action_space_size / math.e)
            return target_entropy
        
        else:
            # 默认使用自适应方法
            return current_entropy * self.target_entropy_ratio
    def learn(self, rewards, log_probs, dones, optimizer,
              action_probs_buffer, action_log_probs_buffer, action_mask_buffer):
        """
        实现熵正则化的REINFORCE算法
        包含两种不同的更新机制：
        1. Alpha参数更新: α ← α + η_α (H_target - H(π))  [控制参数]
        2. 策略参数更新: θ ← θ + η_θ ∇_θ [∑_t R_t log π_θ(a_t|s_t) + αH_t]  [被优化参数]
        """
        R = torch.zeros_like(rewards[0], dtype=torch.float, device=rewards[0].device)
        returns = []
        for r in rewards[::-1]:
            R = r + args.gamma * R
            returns.insert(0, R)
        returns = torch.cat(returns, dim=-1)
        dones = torch.cat(dones, dim=-1)
        log_probs = torch.cat(log_probs, dim=-1)

        losses = []
        total_entropy = 0.0
        n_steps = len(action_probs_buffer)
        device = returns.device

        # 更新训练步数
        self.training_step += 1

        # 计算平均熵
        for t in range(n_steps):
            probs = action_probs_buffer[t]
            log_probs_all = action_log_probs_buffer[t]
            mask = action_mask_buffer[t]
            entropy_t = torch.zeros(probs.shape[0], device=device)
            
            # 只计算可行动作的熵
            for b in range(probs.shape[0]):
                valid_mask = mask[b]
                if valid_mask.sum() > 0:
                    valid_probs = probs[b][valid_mask]
                    valid_log_probs = log_probs_all[b][valid_mask]
                    entropy_t[b] = -(valid_probs * valid_log_probs).sum()
            
            total_entropy += entropy_t.mean()

        # 计算平均熵
        current_entropy = total_entropy / n_steps
        
        # 计算目标熵
        target_entropy = self.get_target_entropy(current_entropy.item(), self.training_step)
        
        # ========== 第一步：更新Alpha参数 (控制参数) ==========
        # 使用拉格朗日对偶公式: α ← α + η_α (H_target - H(π))
        self.update_alpha(current_entropy.item(), target_entropy, self.training_step)

        # 计算策略梯度损失
        for b in range(returns.shape[0]):
            masked_R = torch.masked_select(returns[b], ~dones[b])
            if len(masked_R) > 0:
                masked_R = (masked_R - masked_R.mean()) / (torch.std(masked_R, unbiased=False) + self.eps)
                masked_log_prob = torch.masked_select(log_probs[b], ~dones[b])
                loss = (- masked_log_prob * masked_R).sum()
                losses.append(loss)

        if losses:
            optimizer.zero_grad()
            mean_loss = torch.stack(losses).mean()
            
            # ========== 第二步：计算策略梯度损失 (被优化参数) ==========
            # 策略梯度损失: ∑_t R_t log π_θ(a_t|s_t) + αH_t
            entropy_regularization = self.alpha * current_entropy
            policy_gradient_loss = mean_loss - entropy_regularization
            
            # ========== 第三步：更新策略参数θ ==========
            # 使用策略梯度更新: θ ← θ + η_θ ∇_θ [∑_t R_t log π_θ(a_t|s_t) + αH_t]
            policy_gradient_loss.backward()
            optimizer.step()
            
            # 调试信息
            if hasattr(self, 'debug_counter'):
                self.debug_counter += 1
            else:
                self.debug_counter = 1
                
            # 每50步打印调试信息
            if self.debug_counter % 50 == 0:
                # 计算平均最大概率用于策略确定性检查
                avg_max_prob = torch.stack([probs.max(dim=-1)[0].mean() for probs in action_probs_buffer]).mean()
                
                # 检查alpha是否达到边界
                alpha_status = ""
                if self.alpha <= self.alpha_min + 1e-6:
                    alpha_status = "[MIN]"
                elif self.alpha >= self.alpha_max - 1e-6:
                    alpha_status = "[MAX]"
                
                entropy_error = target_entropy - current_entropy.item()
                
                # print(f'Step: {self.debug_counter}, Alpha: {self.alpha:.4f}{alpha_status}, '
                #       f'Entropy: {current_entropy:.4f}, Target: {target_entropy:.4f}, '
                #       f'Error: {entropy_error:.4f}, Max_Prob: {avg_max_prob:.4f}, '
                #       f'Training_Step: {self.training_step}')

    def validation(self, policy, dev, batch_i=None):

        # fixed seed for fair validation: validation improve not because of different critical path
        # random.seed(1)
        # np.random.seed(1)
        # torch.manual_seed(1)

        # validating...
        validation_start = time.time()
        validation_batch_data = BatchGraph()
        states_val, feasible_actions_val, _ = self.env_validation.reset(instances=self.validation_data,
                                                                        init_type=args.init_type,
                                                                        device=dev)
        while self.env_validation.itr < args.transit:
            validation_batch_data.wrapper(*states_val)
            actions_val = policy(validation_batch_data, feasible_actions_val)[0]
            states_val, _, feasible_actions_val, _ = self.env_validation.step(actions_val, dev)
        states_val, feasible_actions_val, actions_val, _ = None, None, None, None
        validation_batch_data.clean()
        validation_result1 = self.env_validation.incumbent_objs.mean().cpu().item()
        validation_result2 = self.env_validation.current_objs.mean().cpu().item()
        
        # saving model based on validation results
        model_id = f"batch{batch_i}" if batch_i is not None else str(int(time.time()))
        
        # 新的保存逻辑：大于1700batch且Incumbent objs低于842时才保存
        if batch_i is not None and batch_i > 1700 and validation_result1 < 842:
            print(f'Batch {batch_i}: Incumbent objs {validation_result1:.2f} < 842, saving model...')
            torch.save(policy.state_dict(),
                       './savemodel/incumbent_'  # saved model type
                       '{}x{}[{},{}]_{}_{}_{}_'.format(args.j, args.m, args.l, args.h, args.init_type, args.reward_type, args.gamma) +
                       '{}_{}_{}_{}_{}_'.format(args.hidden_dim, args.embedding_layer, args.policy_layer, args.embedding_type, self.dghan_param_for_saved_model) +
                       '{}_{}_{}_{}_{}_{}_'.format(args.lr, args.steps_learn, args.transit, args.batch_size, args.episodes, args.step_validation) +
                       f'{model_id}.pth')
            torch.save(policy.state_dict(),
                       './savemodel/last-step_'  # saved model type
                       '{}x{}[{},{}]_{}_{}_{}_'.format(args.j, args.m, args.l, args.h, args.init_type, args.reward_type, args.gamma) +
                       '{}_{}_{}_{}_{}_'.format(args.hidden_dim, args.embedding_layer, args.policy_layer, args.embedding_type, self.dghan_param_for_saved_model) +
                       '{}_{}_{}_{}_{}_{}_'.format(args.lr, args.steps_learn, args.transit, args.batch_size, args.episodes, args.step_validation) +
                       f'{model_id}.pth')
            self.incumbent_validation_result = validation_result1
            self.current_validation_result = validation_result2
        else:
            # 1700batch之前不保存模型，只更新记录
            if batch_i is not None and batch_i <= 1700:
                print(f'Batch {batch_i}: Early training phase, not saving model.')
                # 更新最佳结果记录，但不保存模型
                if validation_result1 < self.incumbent_validation_result:
                    self.incumbent_validation_result = validation_result1
                if validation_result2 < self.current_validation_result:
                    self.current_validation_result = validation_result2
            else:
                # 1700batch之后但Incumbent objs >= 842，不保存
                print(f'Batch {batch_i}: Incumbent objs {validation_result1:.2f} >= 842, not saving model.')

        validation_end = time.time()

        print('Incumbent objs and final step objs for validation are: {:.2f}  {:.2f}'.format(validation_result1,
                                                                                             validation_result2),
              'validation takes:{:.2f}'.format(validation_end - validation_start))

        return validation_result1, validation_result2

    def train(self):
        dev = 'cuda' if torch.cuda.is_available() else 'cpu'

        torch.manual_seed(100)
        random.seed(100)
        np.random.seed(100)

        policy = Actor(in_dim=3,
                       hidden_dim=args.hidden_dim,
                       embedding_l=args.embedding_layer,
                       policy_l=args.policy_layer,
                       embedding_type=args.embedding_type,
                       heads=args.heads,
                       dropout=args.drop_out).to(dev)

        optimizer = optim.Adam(policy.parameters(), lr=args.lr)

        batch_data = BatchGraph()
        log = []
        validation_log = []

        print()
        for batch_i in range(1, args.episodes // args.batch_size + 1):
            # 更新当前episode
            self.current_episode = batch_i

            # random.seed(batch_i)
            # np.random.seed(batch_i)

            t1 = time.time()

            instances = np.array([uni_instance_gen(args.j, args.m, args.l, args.h) for _ in range(args.batch_size)])
            states, feasible_actions, dones = self.env_training.reset(instances=instances, init_type=args.init_type, device=dev)
            # print(instances)

            reward_log = []
            rewards_buffer = []
            log_probs_buffer = []
            dones_buffer = [dones]
            action_probs_buffer = []
            action_log_probs_buffer = []
            action_mask_buffer = []

            while self.env_training.itr < args.transit:
                batch_data.wrapper(*states)
                actions, log_ps, action_probs, action_log_probs, action_mask = policy(batch_data, feasible_actions)
                states, rewards, feasible_actions, dones = self.env_training.step(actions, dev)

                # store training data
                rewards_buffer.append(rewards)
                log_probs_buffer.append(log_ps)
                dones_buffer.append(dones)
                action_probs_buffer.append(action_probs)
                action_log_probs_buffer.append(action_log_probs)
                action_mask_buffer.append(action_mask)

                # logging reward...
                # reward_log.append(rewards)

                if self.env_training.itr % args.steps_learn == 0:
                    # training...
                    self.learn(
                        rewards_buffer, log_probs_buffer, dones_buffer[:-1], optimizer,
                        action_probs_buffer, action_log_probs_buffer, action_mask_buffer
                    )
                    # clean training data
                    rewards_buffer = []
                    log_probs_buffer = []
                    dones_buffer = [dones]
                    action_probs_buffer = []
                    action_log_probs_buffer = []
                    action_mask_buffer = []

            # learn(rewards_buffer, log_probs_buffer, dones_buffer[:-1])  # old-school training scheme

            t2 = time.time()
            print('Batch {} training takes: {:.2f}'.format(batch_i, t2 - t1),
                  'Mean Performance: {:.2f}'.format(self.env_training.current_objs.cpu().mean().item()),
                  'Alpha: {:.4f}'.format(self.alpha))  # Add display of alpha value
            log.append(self.env_training.current_objs.mean().cpu().item())

            # start validation and saving model & logs...
            if batch_i % args.step_validation == 0:
                # validating...
                validation_result1, validation_result2 = self.validation(policy, dev, batch_i = batch_i)
                validation_log.append([validation_result1, validation_result2])

                # saving log
                np.save('./log/training_log_'
                        '{}x{}[{},{}]_{}_{}_{}_'  # env parameters
                        '{}_{}_{}_{}_{}_'  # model parameters
                        '{}_{}_{}_{}_{}_{}.npy'  # training parameters
                        .format(args.j, args.m, args.l, args.h, args.init_type, args.reward_type, args.gamma,
                                args.hidden_dim, args.embedding_layer, args.policy_layer, args.embedding_type,
                                self.dghan_param_for_saved_model,
                                args.lr, args.steps_learn, args.transit, args.batch_size, args.episodes,
                                args.step_validation),
                        np.array(log))
                np.save('./log/validation_log_'
                        '{}x{}[{},{}]_{}_{}_{}_'  # env parameters
                        '{}_{}_{}_{}_{}_'  # model parameters
                        '{}_{}_{}_{}_{}_{}.npy'  # training parameters
                        .format(args.j, args.m, args.l, args.h, args.init_type, args.reward_type, args.gamma,
                                args.hidden_dim, args.embedding_layer, args.policy_layer, args.embedding_type,
                                self.dghan_param_for_saved_model,
                                args.lr, args.steps_learn, args.transit, args.batch_size, args.episodes,
                                args.step_validation),
                        np.array(validation_log))


if __name__ == '__main__':
    agent = RL2S4JSSP()
    agent.train()