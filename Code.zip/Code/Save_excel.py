import re
import pandas as pd
import os
from pathlib import Path

def parse_test_results(input_file, output_file=None):
    """
    Parse test results from log file and convert to Excel format
    
    Args:
        input_file: Path to the input log file
        output_file: Path to the output Excel file (optional)
    """
    
    # Check if input file exists
    if not os.path.exists(input_file):
        raise FileNotFoundError(f"Input file not found: {input_file}")
    
    # Read text file
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except Exception as e:
        raise RuntimeError(f"Error reading file {input_file}: {e}")
    
    data = []
    current_test = None
    first = True  # Used to determine if this is the first test group
    line_count = 0
    
    print(f"Processing {len(lines)} lines from {input_file}...")
    
    for line_num, line in enumerate(lines, 1):
        line = line.strip()
        if not line:
            continue
            
        # Check if this is a new test group
        test_match = re.match(r'Start testing (\w+)\.\.\.', line)
        if test_match:
            if not first:
                # Insert empty row before new test group for better readability
                data.append({
                    'Test': None, 
                    'Steps': None, 
                    'DRL Gap': None, 
                    'Time per instance': None
                })
            current_test = test_match.group(1)
            first = False
            print(f"Found test group: {current_test}")
            continue

        # Match data rows
        data_match = re.match(
            r'For testing steps:\s*(\d+)\s+DRL Gap:\s*([\d\.]+)\s+DRL results takes:\s*([\d\.]+)\s+per instance\.', 
            line
        )
        if data_match and current_test:
            try:
                steps = int(data_match.group(1))
                gap = float(data_match.group(2))
                time = float(data_match.group(3))
                
                data.append({
                    'Test': current_test,
                    'Steps': steps,
                    'DRL Gap': gap,
                    'Time per instance': time
                })
                line_count += 1
                
            except ValueError as e:
                print(f"Warning: Could not parse data on line {line_num}: {line}")
                print(f"Error: {e}")
                continue

    print(f"Parsed {line_count} data entries from {len(set([d['Test'] for d in data if d['Test']]))} test groups")
    
    # Convert to DataFrame
    df = pd.DataFrame(data)
    
    # Generate output filename if not provided
    if output_file is None:
        input_path = Path(input_file)
        output_file = input_path.with_suffix('.xlsx')
    
    # Save as Excel with formatting
    try:
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Test Results', index=False)
            
            # Get the workbook and worksheet
            workbook = writer.book
            worksheet = writer.sheets['Test Results']
            
            # Auto-adjust column widths
            for column in worksheet.columns:
                max_length = 0
                column_letter = column[0].column_letter
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)
                worksheet.column_dimensions[column_letter].width = adjusted_width
        
        print(f'Successfully saved as {output_file}!')
        
    except Exception as e:
        raise RuntimeError(f"Error saving Excel file: {e}")
    
    return df

def print_summary_statistics(df):
    """
    Print summary statistics of the parsed data
    
    Args:
        df: DataFrame containing the parsed results
    """
    print("\n" + "="*50)
    print("SUMMARY STATISTICS")
    print("="*50)
    
    # Filter out empty rows
    valid_data = df.dropna()
    
    if len(valid_data) == 0:
        print("No valid data found!")
        return
    
    print(f"Total valid entries: {len(valid_data)}")
    print(f"Number of test groups: {valid_data['Test'].nunique()}")
    print(f"Test groups: {', '.join(valid_data['Test'].unique())}")
    
    print(f"\nSteps range: {valid_data['Steps'].min()} - {valid_data['Steps'].max()}")
    print(f"DRL Gap range: {valid_data['DRL Gap'].min():.3f} - {valid_data['DRL Gap'].max():.3f}")
    print(f"Time per instance range: {valid_data['Time per instance'].min():.3f} - {valid_data['Time per instance'].max():.3f}")
    
    print(f"\nMean DRL Gap: {valid_data['DRL Gap'].mean():.3f}")
    print(f"Mean Time per instance: {valid_data['Time per instance'].mean():.3f}")
    
    # Group by test type
    if valid_data['Test'].nunique() > 1:
        print(f"\nResults by test group:")
        summary_by_test = valid_data.groupby('Test').agg({
            'DRL Gap': ['mean', 'min', 'max'],
            'Time per instance': ['mean', 'min', 'max'],
            'Steps': ['count']
        }).round(3)
        print(summary_by_test)

def main():
    """Main execution function"""
    
    # Configuration
    input_file = 'Test_sampled_model_004.out'
    output_file = 'Test-004.xlsx'
    
    try:
        # Parse the test results
        df = parse_test_results(input_file, output_file)
        
        # Print summary statistics
        print_summary_statistics(df)
        
        # Verify the output file was created
        if os.path.exists(output_file):
            file_size = os.path.getsize(output_file)
            print(f"\nOutput file created successfully!")
            print(f"File: {output_file}")
            print(f"Size: {file_size} bytes")
        else:
            print("Warning: Output file was not created!")
            
    except Exception as e:
        print(f"Error processing file: {e}")
        raise

if __name__ == "__main__":
    main()