import re
import matplotlib.pyplot as plt
import numpy as np
import os
from pathlib import Path

def moving_average(data, window_size=10):
    """
    Calculate moving average of data
    
    Args:
        data: Input data array
        window_size: Size of the moving window
    
    Returns:
        Moving average array
    """
    if len(data) < window_size:
        return data
    return np.convolve(data, np.ones(window_size)/window_size, mode='valid')

def extract_data(filename):
    """
    Extract batch numbers and Incumbent objs values from log file
    
    Args:
        filename: Path to the log file
    
    Returns:
        Tuple of (batches, incumbent_objs) arrays
    """
    if not os.path.exists(filename):
        raise FileNotFoundError(f"File not found: {filename}")
    
    batches = []
    incumbent_objs = []
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                # Match pattern: Incumbent objs and final step objs for validation are: X.XX
                # 匹配 "Incumbent objs and final step objs for validation are:" 后的第一个数字
                match = re.search(r'Incumbent objs and final step objs for validation are:\s*([\d\.]+)', line)
                if match:
                    try:
                        incumbent_value = float(match.group(1))
                        incumbent_objs.append(incumbent_value)
                        batches.append(len(incumbent_objs))  # 使用序号作为批次号
                    except ValueError as e:
                        print(f"Warning: Could not parse line {line_num}: {line.strip()}")
                        continue
    except Exception as e:
        raise RuntimeError(f"Error reading file {filename}: {e}")
    
    # Convert to numpy arrays and filter out invalid values
    batches = np.array(batches)
    incumbent_objs = np.array(incumbent_objs)
    
    # Remove NaN and infinite values
    valid_mask = np.isfinite(incumbent_objs)
    batches = batches[valid_mask]
    incumbent_objs = incumbent_objs[valid_mask]
    
    print(f"Extracted {len(batches)} valid Incumbent objs data points from {filename}")
    
    return batches, incumbent_objs

def plotCompare(train_file, test_file, window_size=10, output_path='incumbent_objs_compare_func.png'):
    """
    Function-style plotting comparison between training and testing Incumbent objs
    
    Args:
        train_file: Path to training results file
        test_file: Path to testing results file
        window_size: Window size for moving average smoothing
        output_path: Output path for the saved plot
    """
    print("Starting function-style plotting...")
    
    # Extract data from both files
    train_batches, train_objs = extract_data(train_file)
    test_batches, test_objs = extract_data(test_file)
    
    # Apply smoothing
    train_smoothed = moving_average(train_objs, window_size)
    train_smoothed_batches = train_batches[:len(train_smoothed)]
    
    test_smoothed = moving_average(test_objs, window_size)
    test_smoothed_batches = test_batches[:len(test_smoothed)]
    
    # Create plot
    plt.figure(figsize=(12, 7))
    plt.plot(train_smoothed_batches, train_smoothed, 
             color='blue', linewidth=2, label=f'Training Results (Smoothed, window={window_size})')
    plt.plot(test_smoothed_batches, test_smoothed, 
             color='red', linewidth=2, label=f'Testing Results (Smoothed, window={window_size})')
    
    plt.xlabel('Checkpoint Number', fontsize=12)
    plt.ylabel('Incumbent Objs Value', fontsize=12)
    plt.title('Incumbent Objs Comparison (Function-based)', fontsize=14)
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    # Save plot
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f'Function-based plot saved as {output_path}')
    plt.close()

class ComparePlotter:
    """
    Class-based plotter for comparing training and testing Incumbent objs
    """
    
    def __init__(self, train_file, test_file, window_size=10):
        """
        Initialize the plotter with file paths and smoothing parameters
        
        Args:
            train_file: Path to training results file
            test_file: Path to testing results file
            window_size: Window size for moving average smoothing
        """
        self.train_file = train_file
        self.test_file = test_file
        self.window_size = window_size
        
        print("Initializing ComparePlotter...")
        
        # Load data during initialization
        self.train_batches, self.train_objs = extract_data(self.train_file)
        self.test_batches, self.test_objs = extract_data(self.test_file)
        
        print(f"Loaded training data: {len(self.train_objs)} points")
        print(f"Loaded testing data: {len(self.test_objs)} points")

    def get_statistics(self):
        """
        Get basic statistics of the loaded data
        
        Returns:
            Dictionary containing statistics
        """
        stats = {
            'train': {
                'count': len(self.train_objs),
                'mean': np.mean(self.train_objs),
                'std': np.std(self.train_objs),
                'var': np.var(self.train_objs),
                'min': np.min(self.train_objs),
                'max': np.max(self.train_objs)
            },
            'test': {
                'count': len(self.test_objs),
                'mean': np.mean(self.test_objs),
                'std': np.std(self.test_objs),
                'var': np.var(self.test_objs),
                'min': np.min(self.test_objs),
                'max': np.max(self.test_objs)
            }
        }
        return stats

    def plot(self, output_path='incumbent_objs_compare_class.png', show_raw=True):
        """
        Create and save the comparison plot with legend on the right
        """
        print("Creating class-based plot...")
        
        # Apply smoothing
        train_smoothed = moving_average(self.train_objs, self.window_size)
        train_smoothed_batches = self.train_batches[:len(train_smoothed)]
        
        test_smoothed = moving_average(self.test_objs, self.window_size)
        test_smoothed_batches = self.test_batches[:len(test_smoothed)]
        
        fig, ax = plt.subplots(figsize=(20, 12), facecolor='white')
        ax.set_facecolor('white')
        
        if show_raw:
            ax.plot(self.train_batches, self.train_objs, 
                    color='#6495ED', alpha=0.6, linewidth=2.5,
                    label='HERWA (Raw)', zorder=1)
            ax.plot(self.test_batches, self.test_objs, 
                    color='#FF6B6B', alpha=0.6, linewidth=2.5,
                    label='L2S (Raw)', zorder=2)
        
        ax.plot(train_smoothed_batches, train_smoothed, 
                color='#00008B', linewidth=5.0,
                label=f'HERWA (Smoothed, window={self.window_size})',
                alpha=0.95, zorder=5)
        ax.plot(test_smoothed_batches, test_smoothed, 
                color='#8B0000', linewidth=5.0,
                label=f'L2S (Smoothed, window={self.window_size})',
                alpha=0.95, zorder=6)
        
        ax.set_xlabel('Checkpoint Number', fontsize=28, fontweight='bold')
        ax.set_ylabel('Incumbent Objs Value', fontsize=28, fontweight='bold')
        ax.set_title('Incumbent Objs Comparison', fontsize=32, fontweight='bold')
        
        # ============ 图例放在右上角 ============
        ax.legend(fontsize=24, loc='upper right', framealpha=0.95, edgecolor='black',
                borderpad=1.5, labelspacing=1.2, handlelength=3.0,
                handletextpad=1.0, frameon=True, shadow=True)
        
        ax.tick_params(axis='both', which='major', labelsize=22, width=2.0, length=8)
        ax.grid(True, alpha=0.3, linestyle='--', color='gray', linewidth=1.5)
        
        for spine in ax.spines.values():
            spine.set_linewidth(2.0)
        
        plt.tight_layout(pad=1.5)
        plt.savefig(output_path, dpi=450, bbox_inches='tight', facecolor='white')
        print(f'Class-based plot saved as {output_path}')
        plt.close()
    def plot_variance_trend(self, output_path='incumbent_objs_variance_trend.png', rolling_window=50):
        """
        Create a plot showing rolling variance trend over time
        
        Args:
            output_path: Output path for the variance trend plot
            rolling_window: Window size for rolling variance calculation
        """
        print("Creating variance trend plot...")
        
        def rolling_variance(data, window):
            """Calculate rolling variance"""
            if len(data) < window:
                return np.array([])
            variances = []
            for i in range(len(data) - window + 1):
                variances.append(np.var(data[i:i+window]))
            return np.array(variances)
        
        # Calculate rolling variance
        train_rolling_var = rolling_variance(self.train_objs, rolling_window)
        train_var_batches = self.train_batches[:len(train_rolling_var)]
        
        test_rolling_var = rolling_variance(self.test_objs, rolling_window)
        test_var_batches = self.test_batches[:len(test_rolling_var)]
        
        # Create plot
        plt.figure(figsize=(12, 7))
        
        if len(train_rolling_var) > 0:
            plt.plot(train_var_batches, train_rolling_var, 
                     color='blue', linewidth=2, label=f'Training (Rolling window={rolling_window})')
        
        if len(test_rolling_var) > 0:
            plt.plot(test_var_batches, test_rolling_var, 
                     color='red', linewidth=2, label=f'Testing (Rolling window={rolling_window})')
        
        plt.xlabel('Checkpoint Number', fontsize=12)
        plt.ylabel('Rolling Variance', fontsize=12)
        plt.title('Rolling Variance of Incumbent Objs Over Time', fontsize=14)
        plt.legend(fontsize=11)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        
        # Save plot
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f'Variance trend plot saved as {output_path}')
        plt.close()
    

    def plot_statistics(self, output_path='incumbent_objs_statistics.png'):
        """
        Create a statistical comparison plot showing mean and variance
        
        Args:
            output_path: Output path for the statistics plot
        """
        print("Creating statistics comparison plot...")
        
        # Calculate statistics
        train_mean = np.mean(self.train_objs)
        train_var = np.var(self.train_objs)
        train_std = np.std(self.train_objs)
        
        test_mean = np.mean(self.test_objs)
        test_var = np.var(self.test_objs)
        test_std = np.std(self.test_objs)
        
        # Create figure with two subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6), facecolor='white')
        
        # Define colors
        train_color = '#6495ED'  # Blue
        test_color = '#FF6B6B'   # Red
        
        # ============ Left subplot: Mean Comparison ============
        categories = ['HERWA', 'L2S']
        means = [train_mean, test_mean]
        colors = [train_color, test_color]
        
        bars1 = ax1.bar(categories, means, color=colors, alpha=0.8, 
                        edgecolor='black', linewidth=1.5, width=0.6)
        
        # Add value labels on top of bars
        for i, (bar, mean_val) in enumerate(zip(bars1, means)):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height,
                    f'{mean_val:.2f}',
                    ha='center', va='bottom', fontsize=12, fontweight='bold')
        
        ax1.set_ylabel('Mean Incumbent Objs', fontsize=13, fontweight='bold')
        ax1.set_title('Mean Incumbent Objs Comparison', fontsize=14, fontweight='bold')
        ax1.grid(True, alpha=0.3, axis='y', linestyle='--')
        ax1.set_ylim(0, max(means) * 1.15)  # Add 15% space for labels
        
        # ============ Right subplot: Variance Comparison ============
        variances = [train_var, test_var]
        
        bars2 = ax2.bar(categories, variances, color=colors, alpha=0.8,
                        edgecolor='black', linewidth=1.5, width=0.6)
        
        # Add value labels with both variance and std
        for i, (bar, var_val, std_val) in enumerate(zip(bars2, variances, [train_std, test_std])):
            height = bar.get_height()
            # Main label: Variance
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                    f'Var: {var_val:.2f}\nStd: {std_val:.2f}',
                    ha='center', va='bottom', fontsize=11, fontweight='bold')
        
        ax2.set_ylabel('Variance of Incumbent Objs', fontsize=13, fontweight='bold')
        ax2.set_title(f'Variance Comparison', fontsize=14, fontweight='bold')
        
        # Add variance and std as subtitle in the top right
        ax2.text(0.98, 0.98, f'Var: {test_var:.2f}\nStd: {test_std:.2f}',
                transform=ax2.transAxes, ha='right', va='top',
                fontsize=10, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        ax2.grid(True, alpha=0.3, axis='y', linestyle='--')
        ax2.set_ylim(0, max(variances) * 1.2)  # Add 20% space for labels
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f'Statistics plot saved as {output_path}')
        plt.close()
        
        # Print statistics summary
        print(f"\n{'='*50}")
        print(f"Statistical Summary:")
        print(f"{'='*50}")
        print(f"HERWA (Training):")
        print(f"  Mean: {train_mean:.2f}")
        print(f"  Variance: {train_var:.2f}")
        print(f"  Std Dev: {train_std:.2f}")
        print(f"\nL2S (Testing):")
        print(f"  Mean: {test_mean:.2f}")
        print(f"  Variance: {test_var:.2f}")
        print(f"  Std Dev: {test_std:.2f}")
        print(f"{'='*50}\n")

    def plot_statistics_grouped(self, output_path='multi_seed_statistics_grouped.png'):
        """
        Create grouped bar chart for clearer comparison
        """
        print("Creating grouped statistics comparison plot...")
        
        # Calculate all statistics
        l2s_mean = np.mean(self.l2s_objs)
        l2s_var = np.var(self.l2s_objs)
        l2s_std = np.std(self.l2s_objs)
        
        herwa_means = [np.mean(data['objs']) for data in self.herwa_data]
        herwa_vars = [np.var(data['objs']) for data in self.herwa_data]
        herwa_stds = [np.std(data['objs']) for data in self.herwa_data]
        
        # Create figure
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6), facecolor='white')
        
        n_seeds = len(self.herwa_data)
        x = np.arange(2)  # Two groups: HERWA and L2S
        width = 0.15  # Width of individual bars
        
        herwa_colors = ['#4169E1', '#6495ED', '#87CEEB']
        
        # ============ Left: Mean Comparison (Grouped) ============
        # Plot HERWA seeds as grouped bars
        for i in range(n_seeds):
            offset = (i - n_seeds/2 + 0.5) * width
            bars = ax1.bar(x[0] + offset, herwa_means[i], width,
                        label=self.seed_labels[i],
                        color=herwa_colors[i], alpha=0.85,
                        edgecolor='black', linewidth=1)
            
            # Add value label
            ax1.text(x[0] + offset, herwa_means[i],
                    f'{herwa_means[i]:.1f}',
                    ha='center', va='bottom', fontsize=8, fontweight='bold')
        
        # Plot L2S
        bars_l2s = ax1.bar(x[1], l2s_mean, width*n_seeds,
                        label='L2S', color='#EE6666', alpha=0.85,
                        edgecolor='black', linewidth=1)
        ax1.text(x[1], l2s_mean, f'{l2s_mean:.1f}',
                ha='center', va='bottom', fontsize=8, fontweight='bold')
        
        ax1.set_ylabel('Mean Incumbent Objs', fontsize=13, fontweight='bold')
        ax1.set_title('Mean Comparison', fontsize=14, fontweight='bold')
        ax1.set_xticks(x)
        ax1.set_xticklabels(['HERWA', 'L2S'], fontsize=12)
        ax1.legend(fontsize=9, loc='upper right')
        ax1.grid(True, alpha=0.3, axis='y')
        ax1.set_axisbelow(True)
        
        # ============ Right: Variance Comparison (Grouped) ============
        for i in range(n_seeds):
            offset = (i - n_seeds/2 + 0.5) * width
            bars = ax2.bar(x[0] + offset, herwa_vars[i], width,
                        color=herwa_colors[i], alpha=0.85,
                        edgecolor='black', linewidth=1)
            
            ax2.text(x[0] + offset, herwa_vars[i],
                    f'{herwa_vars[i]:.1f}',
                    ha='center', va='bottom', fontsize=8, fontweight='bold')
        
        bars_l2s = ax2.bar(x[1], l2s_var, width*n_seeds,
                        color='#EE6666', alpha=0.85,
                        edgecolor='black', linewidth=1)
        ax2.text(x[1], l2s_var, f'{l2s_var:.1f}',
                ha='center', va='bottom', fontsize=8, fontweight='bold')
        
        ax2.set_ylabel('Variance of Incumbent Objs', fontsize=13, fontweight='bold')
        ax2.set_title('Variance Comparison', fontsize=14, fontweight='bold')
        ax2.set_xticks(x)
        ax2.set_xticklabels(['HERWA', 'L2S'], fontsize=12)
        ax2.grid(True, alpha=0.3, axis='y')
        ax2.set_axisbelow(True)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f'Grouped statistics plot saved as {output_path}')
        plt.close()

def main():
    """
    Main execution function
    """
    # Configuration
    train_file = 'Train_seed100.out'
    test_file = 'TrainResult.out'
    window_size = 10
    
    try:
        print("Starting Incumbent objs comparison analysis...")
        print("="*50)
        
        # Function-based approach
        print("\n1. Function-based plotting:")
        plotCompare(train_file, test_file, window_size=window_size)
        
        # Class-based approach
        print("\n2. Class-based plotting:")
        plotter = ComparePlotter(train_file, test_file, window_size=window_size)
        
        # Print statistics
        stats = plotter.get_statistics()
        print(f"\nTraining Statistics:")
        print(f"  Count: {stats['train']['count']}")
        print(f"  Mean: {stats['train']['mean']:.4f}")
        print(f"  Std: {stats['train']['std']:.4f}")
        print(f"  Variance: {stats['train']['var']:.4f}")
        print(f"  Range: [{stats['train']['min']:.4f}, {stats['train']['max']:.4f}]")
        
        print(f"\nTesting Statistics:")
        print(f"  Count: {stats['test']['count']}")
        print(f"  Mean: {stats['test']['mean']:.4f}")
        print(f"  Std: {stats['test']['std']:.4f}")
        print(f"  Variance: {stats['test']['var']:.4f}")
        print(f"  Range: [{stats['test']['min']:.4f}, {stats['test']['max']:.4f}]")
        
        # Create plots
        plotter.plot(show_raw=True)
        plotter.plot_statistics()
        plotter.plot_variance_trend(rolling_window=50)  # 新增方差变化趋势图
        
        print("\n" + "="*50)
        print("Analysis completed successfully!")
        
    except Exception as e:
        print(f"Error during analysis: {e}")
        raise

if __name__ == '__main__':
    main()