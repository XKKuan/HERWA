import argparse
parser = argparse.ArgumentParser(description='DRL-LSJSP')

# env parameters
parser.add_argument('--j', type=int, default=10)
parser.add_argument('--m', type=int, default=10)
parser.add_argument('--l', type=int, default=1)
parser.add_argument('--h', type=int, default=99)
parser.add_argument('--init_type', type=str, default='fdd-divide-mwkr')
parser.add_argument('--reward_type', type=str, default='yaoxin')
parser.add_argument('--gamma', type=float, default=1)
# model parameters
parser.add_argument('--hidden_dim', type=int, default=128)
parser.add_argument('--embedding_layer', type=int, default=4)
parser.add_argument('--policy_layer', type=int, default=4)
parser.add_argument('--embedding_type', type=str, default='gin+dghan')  # 'gin', 'dghan', 'gin+dghan'
parser.add_argument('--heads', type=int, default=1)  # dghan parameters
parser.add_argument('--drop_out', type=float, default=0.)  # dghan parameters
# training parameters
parser.add_argument('--lr', type=float, default=5e-5)
parser.add_argument('--steps_learn', type=int, default=10)
parser.add_argument('--transit', type=int, default=500)
parser.add_argument('--batch_size', type=int, default=64)
parser.add_argument('--episodes', type=int, default=128000)
parser.add_argument('--step_validation', type=int, default=10)

# ========== 熵正则化参数 ==========
parser.add_argument('--target_entropy_method', type=str, default='cosine_annealing', 
                    choices=['fixed', 'adaptive', 'moving_avg', 'progressive', 'formula', 'cosine_annealing'],
                    help='Target entropy calculation method')

# Cosine Annealing with Warm Restart 参数
parser.add_argument('--n_restart', type=int, default=4, 
                    help='Number of restarts for cosine annealing')
parser.add_argument('--k_min', type=int, default=3, 
                    choices=[2, 3, 4],
                    help='Convergence strength parameter k, controls H_min')
parser.add_argument('--avg_action_space_size', type=int, default=15, 
                    help='Average action space size |A| for entropy calculation')

args = parser.parse_args()