import os
import glob

# ========== 配置区域 ==========
# 设置要删除的文件名前缀
prefix = "in"  # 可以修改为 "incumbent" 或其他前缀

# 设置savemodel文件夹路径
savemodel_dir = "./savemodel"

# ========== 删除逻辑 ==========
def delete_models_by_prefix(prefix, savemodel_dir):
    """根据前缀删除模型文件"""
    # 检查savemodel文件夹是否存在
    if not os.path.exists(savemodel_dir):
        print(f"Error: {savemodel_dir} directory does not exist!")
        return False
    
    print(f"Looking for files with prefix '{prefix}' in {savemodel_dir}...")
    
    # 获取savemodel文件夹中所有以指定前缀开头的文件
    pattern = os.path.join(savemodel_dir, f"{prefix}*")
    files_to_delete = glob.glob(pattern)
    
    if not files_to_delete:
        print(f"No files found with prefix '{prefix}' in {savemodel_dir}")
        return True
    
    print(f"Found {len(files_to_delete)} files to delete:")
    for filepath in files_to_delete:
        filename = os.path.basename(filepath)
        print(f"  - {filename}")
    
    # 确认删除
    confirm = input(f"\nAre you sure you want to delete these {len(files_to_delete)} files? (y/N): ")
    if confirm.lower() != 'y':
        print("Operation cancelled.")
        return False
    
    # 删除找到的文件
    deleted_count = 0
    for filepath in files_to_delete:
        try:
            os.remove(filepath)
            filename = os.path.basename(filepath)
            print(f"Deleted: {filename}")
            deleted_count += 1
        except Exception as e:
            filename = os.path.basename(filepath)
            print(f"Failed to delete {filename}: {e}")
    
    print(f"\nSuccessfully deleted {deleted_count} files.")
    return True

# ========== 执行删除 ==========
if __name__ == "__main__":
    print("=" * 50)
    print("Model File Deletion Tool")
    print("=" * 50)
    print(f"Target directory: {savemodel_dir}")
    print(f"File prefix: {prefix}")
    print("=" * 50)
    
    delete_models_by_prefix(prefix, savemodel_dir)